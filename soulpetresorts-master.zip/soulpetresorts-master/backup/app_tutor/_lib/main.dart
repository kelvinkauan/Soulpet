import 'package:flutter/material.dart';
import 'package:app_tutor/app/app_module.dart';

void main() => runApp(AppModule());

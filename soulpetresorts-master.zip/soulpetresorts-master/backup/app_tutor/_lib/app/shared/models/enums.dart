
enum ViewTypes{ALTER, CREATE, LISTING}

enum StatusTypes{ERROR, SUCCESS}

const BASE_URL = 'https://soulpet.sevenclicks.us/api';


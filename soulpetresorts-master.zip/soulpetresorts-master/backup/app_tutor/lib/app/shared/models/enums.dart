
enum ViewTypes{ALTER, CREATE, LISTING}

enum StatusTypes{ERROR, SUCCESS}

enum PhotoMode{CAMERA, GALLERY}

const BASE_URL = 'https://soulpet.sevenclicks.us/api';
const PET_IMAGE_DEFAULT = 'assets/images/user.png';


const String URL_API= "https://jsonplaceholder.typicode.com";
// const String URL_API= "https://soulpet.com.br/api";
const String URL_IMG= "https://quefazer.com.br/uploads/avatar";

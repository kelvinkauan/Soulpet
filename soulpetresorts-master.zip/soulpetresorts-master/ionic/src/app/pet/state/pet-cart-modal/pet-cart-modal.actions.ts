export class OpenPetCartModal {
    static readonly type = '[Pets] Open Pet Cart Modal';
}

export class ClosePetCartModal {
    static readonly type = '[Pets] Close Pet Cart Modal';
}


import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-pet-sitter',
    templateUrl: './pet-sitter.page.html',
    styleUrls: ['./pet-sitter.page.scss'],
})
export class PetSitterPage implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}

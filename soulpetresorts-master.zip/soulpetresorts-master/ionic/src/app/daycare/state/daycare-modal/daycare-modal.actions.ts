export class OpenDaycareModal {
    static readonly type = '[Daycare] Open Daycare Modal';
}

export class CloseDaycareModal {
    static readonly type = '[Daycare] Close Daycare Modal';
}

export class OpenDaycareCheckModal {
    static readonly type = '[Daycare] Open Daycare Check Modal';
}

export class CloseDaycareCheckModal {
    static readonly type = '[Daycare] Close Daycare Check Modal';
}

export class OpenDaycareClassModal {
    static readonly type = '[Daycare] Open Daycare Class Modal';
}

export class CloseDaycareClassModal {
    static readonly type = '[Daycare] Close Daycare Class Modal';
}

